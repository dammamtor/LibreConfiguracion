package com.example.examendanielmt

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.examendanielmt.data.DataSource
import com.example.examendanielmt.data.Producto
import com.example.examendanielmt.ui.theme.ExamenDanielMTTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ExamenDanielMTTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ExamenApp()
                }
            }
        }
    }
}

@Composable
fun ExamenApp(modifier: Modifier = Modifier) {
    var nombrex by remember { mutableStateOf("") }
    var precio by remember { mutableStateOf("") }


    var nuevoProducto by remember { mutableStateOf("") }
    var mensaje = addUpdate(nombrex, precio)

    Column(
        modifier = Modifier
            .fillMaxWidth()
    ) {
        Text(
            text = "Hola soy alumno: Daniel Mamani Torres",
            modifier = Modifier
                .fillMaxWidth()
                .background(Color.Gray)
                .padding(start = 20.dp, end = 20.dp)
        )
        Text(
            text = nuevoProducto,
            modifier = Modifier
                .background(Color.Gray)
                .fillMaxWidth()
        )
        EditTextField(
            label = "Nombre",
            value = nombrex,
            onValueChanged = { nombrex = it },
            modifier = Modifier
        )
        Spacer(modifier = Modifier.height(8.dp))
        EditTextField(
            label = "Precio",
            value = precio,
            onValueChanged = { precio = it },
            modifier = Modifier
        )
        Spacer(modifier = Modifier.height(8.dp))
        Button(
            onClick = { nuevoProducto = mensaje
            }
        ) {
            Text(text = "Add/Update producto")
        }
        productoListaCard(affirmationList = DataSource.productos)
    }
}

@Composable
fun productoCard(affirmation: Producto, modifier: Modifier = Modifier) {
    Card {
        Column {
            Text(
                text = "Nombre: " + affirmation.nombre,
                modifier = Modifier
                    .background(Color.Yellow)
                    .padding(20.dp)
            )
            Text(
                text = "Precio: " + affirmation.precio.toString(),
                modifier = Modifier
                    .background(Color.Cyan)
                    .padding(20.dp)
            )
        }
    }
}

@Composable
fun productoListaCard(affirmationList: List<Producto>, modifier: Modifier = Modifier) {
    LazyColumn {
        items(affirmationList) { topic ->
            productoCard(affirmation = topic)
            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditTextField(
    label: String,
    value: String,
    onValueChanged: (String) -> Unit,
    modifier: Modifier
){
    TextField(
        value = value,
        onValueChange = onValueChanged,
        label = { Text(text = label)},
        modifier = Modifier
    )
}


@Composable
fun addUpdate(nombre: String, precio: String): String {
    val productoExistente = DataSource.productos.find { it.nombre == nombre }
    val precioInt = precio.toIntOrNull() ?: 0

    return if (productoExistente != null) {
        if (productoExistente.precio == precioInt) {
            "No se ha modificado nada del producto $nombre, el precio es el mismo"
        } else {
            productoExistente.precio = precioInt
            "Del producto $nombre se ha modificado el precio de: ${productoExistente.precio} euros a $precio euros"
        }
    } else {
        DataSource.productos.add(Producto(nombre, precioInt))
        "Se ha añadido el producto $nombre con precio $precio"
    }
}


@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    ExamenApp()
}