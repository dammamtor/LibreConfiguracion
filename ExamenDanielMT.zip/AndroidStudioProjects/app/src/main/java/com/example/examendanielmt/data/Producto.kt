package com.example.examendanielmt.data

data class Producto (
    val nombre: String,
    var precio: Int
)